# PADELBEANS Financial OS — Standalone Web Application
PT Sport Universal Indonesia (Salatiga & Fort Williem Ambarawa)

## Cara Deploy Instan (Pilih Salah Satu):

### Opsi A: Netlify Drop (Paling Mudah, 30 Detik)
1. Buka browser: https://app.netlify.com/drop
2. Ekstrak file zip ini ke sebuah folder.
3. Tarik dan lepas (drag & drop) folder tersebut ke area upload Netlify Drop.
4. Web app langsung aktif dengan URL gratis (misal: padelbeans.netlify.app).

### Opsi B: Vercel (Standar Developer)
1. Buka https://vercel.com, klik 'Add New' -> 'Project'.
2. Hubungkan via GitHub repository atau drag & drop folder ini.
3. Klik Deploy.
